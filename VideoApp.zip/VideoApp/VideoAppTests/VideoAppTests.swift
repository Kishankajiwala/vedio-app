//
//  VideoAppTests.swift
//  VideoAppTests
//
//  Created by Dhruv Mahyavanshi on 23/04/25.
//

import Testing
@testable import VideoApp

struct VideoAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
