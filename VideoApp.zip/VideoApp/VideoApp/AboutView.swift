import SwiftUI

struct AboutView: View {
    var body: some View {
        Text("This is a simple SwiftUI video app.\nBuilt for demo and fun.kishan kajiwala[202403103520024]")
            .padding()
            .navigationTitle("About")
    }
}
