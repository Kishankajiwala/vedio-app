import SwiftUI
import PhotosUI
import AVKit

struct VideoPickerView: View {
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var player: AVPlayer? = nil

    var body: some View {
        VStack {
            if let player = player {
                VideoPlayer(player: player)
                    .frame(height: 300)
            } else {
                Text("No video selected")
                    .foregroundColor(.gray)
            }

            PhotosPicker("Select Video", selection: $selectedItem, matching: .videos)
                .padding()
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let url = saveToTemp(data: data) {
                            player = AVPlayer(url: url)
                            player?.play()
                        }
                    }
                }
        }
        .navigationTitle("Pick a Video")
    }

    func saveToTemp(data: Data) -> URL? {
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("pickedVideo.mp4")
        try? data.write(to: tempURL)
        return tempURL
    }
}
