//
//  VideoAppApp.swift
//  VideoApp
//
//  Created by Dhruv Mahyavanshi on 23/04/25.
//

import SwiftUI

@main
struct VideoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
