import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("Pick Phone Video") {
                    VideoPickerView()
                }
                NavigationLink("About") {
                    AboutView()
                }
            }
            .navigationTitle("Video App")
        }
    }
}

