import SwiftUI
import AVKit

struct VideoDetailView: View {
    var videoName: String
    @State private var player: AVPlayer
    @State private var isPlaying = false
    @State private var speed: Float = 1.0

    init(videoName: String) {
        self.videoName = videoName
        if let url = Bundle.main.url(forResource: videoName, withExtension: "mp4") {
            _player = State(initialValue: AVPlayer(url: url))
        } else {
            print("❌ Video file not found!")
            _player = State(initialValue: AVPlayer()) // fallback empty player
        }
    }

    var body: some View {
        VStack {
            VideoPlayer(player: player)
                .frame(height: 250)
                .onDisappear { player.pause() }

            HStack {
                Button(isPlaying ? "Pause" : "Play") {
                    isPlaying ? player.pause() : player.play()
                    isPlaying.toggle()
                }
                Button("Speed \(speed == 1.0 ? "2x" : "1x")") {
                    speed = (speed == 1.0) ? 2.0 : 1.0
                    player.rate = isPlaying ? speed : 0
                }
            }
            .padding()
        }
        .navigationTitle(videoName.capitalized)
    }
}
